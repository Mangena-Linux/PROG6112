package hospital;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Manages the collection of registered patients using the ArrayList class
 * (Feature 1 - Patient Management, and part of Feature 3 - Reports).
 */
public class PatientManager {

    private List<Patient> patients;

    public PatientManager() {
        patients = new ArrayList<>();
    }

    /**
     * Registers a new patient, preventing duplicate Patient IDs.
     */
    public void registerPatient(Patient patient) throws DuplicatePatientException {
        for (Patient p : patients) {
            if (p.getPatientId().equalsIgnoreCase(patient.getPatientId())) {
                throw new DuplicatePatientException(
                        "A patient with ID " + patient.getPatientId() + " is already registered.");
            }
        }
        patients.add(patient);
    }

    /**
     * Searches for a patient by Patient ID.
     */
    public Patient searchPatient(String patientId) throws PatientNotFoundException {
        for (Patient p : patients) {
            if (p.getPatientId().equalsIgnoreCase(patientId)) {
                return p;
            }
        }
        throw new PatientNotFoundException("No patient found with ID " + patientId);
    }

    /**
     * Updates an existing patient's editable details.
     */
    public void updatePatient(String patientId, String firstName, String lastName,
                               int age, String gender, String medicalCondition)
            throws PatientNotFoundException {
        Patient p = searchPatient(patientId);
        p.setFirstName(firstName);
        p.setLastName(lastName);
        p.setAge(age);
        p.setGender(gender);
        p.setMedicalCondition(medicalCondition);
    }

    /**
     * Deletes a patient record by Patient ID. Returns the removed patient
     * so the caller can release any bed it may hold.
     */
    public Patient deletePatient(String patientId) throws PatientNotFoundException {
        Patient p = searchPatient(patientId);
        patients.remove(p);
        return p;
    }

    public List<Patient> getAllPatients() {
        return patients;
    }

    public int getTotalRegistered() {
        return patients.size();
    }

    public void displayAllPatients() {
        System.out.println("\n=== All Registered Patients (" + patients.size() + ") ===");
        if (patients.isEmpty()) {
            System.out.println("No patients registered yet.");
            return;
        }
        for (Patient p : patients) {
            p.displayDetails();
        }
    }

    /**
     * Sorts patients by surname (last name), alphabetically.
     */
    public void sortBySurname() {
        patients.sort(Comparator.comparing(Patient::getLastName, String.CASE_INSENSITIVE_ORDER));
    }

    /**
     * Sorts patients by Patient ID.
     */
    public void sortByPatientId() {
        patients.sort(Comparator.comparing(Patient::getPatientId, String.CASE_INSENSITIVE_ORDER));
    }
}
