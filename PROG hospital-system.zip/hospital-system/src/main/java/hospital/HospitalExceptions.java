package hospital;

/**
 * Thrown when attempting to register a patient with a Patient ID that
 * already exists in the system.
 */
class DuplicatePatientException extends Exception {
    public DuplicatePatientException(String message) {
        super(message);
    }
}

/**
 * Thrown when a search/update/delete operation cannot find a patient
 * with the given Patient ID.
 */
class PatientNotFoundException extends Exception {
    public PatientNotFoundException(String message) {
        super(message);
    }
}

/**
 * Thrown when attempting to allocate a bed that is already occupied,
 * or when no beds are available in the ward.
 */
class BedUnavailableException extends Exception {
    public BedUnavailableException(String message) {
        super(message);
    }
}

/**
 * Thrown when a patient who is not an Inpatient (i.e. Outpatient or
 * Emergency) is passed to a bed allocation operation.
 */
class InvalidPatientCategoryException extends Exception {
    public InvalidPatientCategoryException(String message) {
        super(message);
    }
}
