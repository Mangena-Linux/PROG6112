package hospital;

/**
 * Represents the category a patient falls under.
 * Only INPATIENT category may be allocated a hospital bed.
 */
public enum PatientCategory {
    INPATIENT,
    OUTPATIENT,
    EMERGENCY
}
