package hospital;

/**
 * Manages the hospital ward, which contains 20 beds arranged in a
 * 4 x 5 layout (Feature 2 - Bed Management).
 */
public class Ward {

    public static final int ROWS = 4;
    public static final int COLS = 5;
    public static final int TOTAL_BEDS = ROWS * COLS;

    // 2D array holding the Inpatient occupying each bed (null = available)
    private Inpatient[][] beds;

    public Ward() {
        beds = new Inpatient[ROWS][COLS];
    }

    /**
     * Generates the bed ID for a given row/column, e.g. row 0 col 0 -> "B01".
     */
    private String bedIdFor(int row, int col) {
        int bedNumber = row * COLS + col + 1;
        return String.format("B%02d", bedNumber);
    }

    /**
     * Converts a bed ID (e.g. "B07") into its row/column position.
     * Returns null if the bed ID is invalid.
     */
    private int[] positionFor(String bedId) {
        if (bedId == null || !bedId.matches("(?i)B\\d{2}")) {
            return null;
        }
        int bedNumber = Integer.parseInt(bedId.substring(1));
        if (bedNumber < 1 || bedNumber > TOTAL_BEDS) {
            return null;
        }
        int index = bedNumber - 1;
        return new int[]{index / COLS, index % COLS};
    }

    /**
     * Allocates a specific bed to an inpatient.
     */
    public void allocateBed(String bedId, Inpatient patient)
            throws BedUnavailableException {
        if (patient.getBedNumber() != null) {
            throw new BedUnavailableException("Patient " + patient.getPatientId()
                    + " already occupies bed " + patient.getBedNumber() + ".");
        }
        int[] pos = positionFor(bedId);
        if (pos == null) {
            throw new BedUnavailableException("Invalid bed ID: " + bedId);
        }
        if (beds[pos[0]][pos[1]] != null) {
            throw new BedUnavailableException("Bed " + bedId + " is already occupied.");
        }
        beds[pos[0]][pos[1]] = patient;
        // Store the canonical bed ID (e.g. "B03"), not whatever case the caller passed in,
        // so the patient record always matches what displayWardLayout() shows.
        patient.setBedNumber(bedIdFor(pos[0], pos[1]));
        patient.setWardNumber(1);
    }

    /**
     * Allocates the first available bed to an inpatient automatically.
     * Returns the bed ID allocated.
     */
    public String allocateFirstAvailableBed(Inpatient patient) throws BedUnavailableException {
        if (patient.getBedNumber() != null) {
            throw new BedUnavailableException("Patient " + patient.getPatientId()
                    + " already occupies bed " + patient.getBedNumber() + ".");
        }
        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                if (beds[r][c] == null) {
                    String bedId = bedIdFor(r, c);
                    beds[r][c] = patient;
                    patient.setBedNumber(bedId);
                    patient.setWardNumber(1);
                    return bedId;
                }
            }
        }
        throw new BedUnavailableException("No beds are available in the ward.");
    }

    /**
     * Releases the bed occupied by the given patient ID.
     */
    public void releaseBed(String patientId) throws BedUnavailableException {
        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                Inpatient occupant = beds[r][c];
                if (occupant != null && occupant.getPatientId().equalsIgnoreCase(patientId)) {
                    occupant.setBedNumber(null);
                    beds[r][c] = null;
                    return;
                }
            }
        }
        throw new BedUnavailableException("No bed is currently allocated to patient " + patientId);
    }

    public boolean isFull() {
        return getAvailableBedCount() == 0;
    }

    public int getAvailableBedCount() {
        int count = 0;
        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                if (beds[r][c] == null) count++;
            }
        }
        return count;
    }

    public int getOccupiedBedCount() {
        return TOTAL_BEDS - getAvailableBedCount();
    }

    public double getOccupancyPercentage() {
        return (getOccupiedBedCount() / (double) TOTAL_BEDS) * 100.0;
    }

    /**
     * Displays the complete ward layout (4 x 5 grid) using nested loops,
     * marking each bed as occupied [X] or available [ ].
     */
    public void displayWardLayout() {
        System.out.println("\n=== Ward Layout (4 x 5) ===");
        for (int r = 0; r < ROWS; r++) {
            StringBuilder row = new StringBuilder();
            for (int c = 0; c < COLS; c++) {
                String bedId = bedIdFor(r, c);
                String status = (beds[r][c] == null) ? " " : "X";
                row.append(String.format("[%s:%s] ", bedId, status));
            }
            System.out.println(row.toString());
        }
        System.out.println("Legend: X = Occupied, blank = Available");
    }

    public void displayAvailableBeds() {
        System.out.println("\n=== Available Beds ===");
        boolean any = false;
        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                if (beds[r][c] == null) {
                    System.out.println(bedIdFor(r, c));
                    any = true;
                }
            }
        }
        if (!any) System.out.println("No beds available.");
    }

    public void displayOccupiedBeds() {
        System.out.println("\n=== Occupied Beds ===");
        boolean any = false;
        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                if (beds[r][c] != null) {
                    System.out.println(bedIdFor(r, c) + " -> " + beds[r][c].getPatientId()
                            + " (" + beds[r][c].getFirstName() + " " + beds[r][c].getLastName() + ")");
                    any = true;
                }
            }
        }
        if (!any) System.out.println("No beds occupied.");
    }
}
