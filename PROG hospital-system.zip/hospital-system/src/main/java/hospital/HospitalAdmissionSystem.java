package hospital;

import java.util.Scanner;

/**
 * MediCare Hospital - Patient Admission System.
 * Console-based, menu-driven application for one ward of 20 beds.
 */
public class HospitalAdmissionSystem {

    private final PatientManager patientManager = new PatientManager();
    private final Ward ward = new Ward();
    private final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        HospitalAdmissionSystem app = new HospitalAdmissionSystem();
        app.run();
    }

    public void run() {
        boolean running = true;
        while (running) {
            printMainMenu();
            int choice = readInt("Enter your choice: ");
            switch (choice) {
                case 1 -> registerPatientFlow();
                case 2 -> searchPatientFlow();
                case 3 -> updatePatientFlow();
                case 4 -> deletePatientFlow();
                case 5 -> patientManager.displayAllPatients();
                case 6 -> allocateBedFlow();
                case 7 -> releaseBedFlow();
                case 8 -> ward.displayWardLayout();
                case 9 -> ward.displayAvailableBeds();
                case 10 -> ward.displayOccupiedBeds();
                case 11 -> reportsMenu();
                case 0 -> {
                    running = false;
                    System.out.println("Exiting MediCare Hospital Patient Admission System. Goodbye!");
                }
                default -> System.out.println("Invalid choice. Please select an option from the menu.");
            }
        }
        scanner.close();
    }

    private void printMainMenu() {
        System.out.println("\n===================================================");
        System.out.println(" MEDICARE HOSPITAL - PATIENT ADMISSION SYSTEM");
        System.out.println("===================================================");
        System.out.println(" 1. Register New Patient");
        System.out.println(" 2. Search Patient by ID");
        System.out.println(" 3. Update Patient Details");
        System.out.println(" 4. Delete Patient");
        System.out.println(" 5. Display All Patients");
        System.out.println(" 6. Allocate Bed to Inpatient");
        System.out.println(" 7. Release Bed");
        System.out.println(" 8. Display Ward Layout");
        System.out.println(" 9. Display Available Beds");
        System.out.println("10. Display Occupied Beds");
        System.out.println("11. Reports Menu");
        System.out.println(" 0. Exit");
        System.out.println("===================================================");
    }

    // ---------------- Patient Management (Feature 1) ----------------

    private void registerPatientFlow() {
        System.out.println("\n--- Register New Patient ---");
        String id = readNonEmptyString("Enter Patient ID: ");
        String firstName = readNonEmptyString("Enter First Name: ");
        String lastName = readNonEmptyString("Enter Last Name: ");
        int age = readPositiveInt("Enter Age: ");
        String gender = readNonEmptyString("Enter Gender: ");
        String condition = readNonEmptyString("Enter Medical Condition: ");
        PatientCategory category = readCategory();

        try {
            Patient patient;
            if (category == PatientCategory.INPATIENT) {
                patient = new Inpatient(id, firstName, lastName, age, gender, condition);
            } else {
                patient = new Patient(id, firstName, lastName, age, gender, condition, category);
            }
            patientManager.registerPatient(patient);
            System.out.println("Patient registered successfully.");
        } catch (DuplicatePatientException e) {
            System.out.println("Registration failed: " + e.getMessage());
        }
    }

    private void searchPatientFlow() {
        System.out.println("\n--- Search Patient ---");
        String id = readNonEmptyString("Enter Patient ID to search: ");
        try {
            Patient patient = patientManager.searchPatient(id);
            patient.displayDetails();
        } catch (PatientNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }

    private void updatePatientFlow() {
        System.out.println("\n--- Update Patient Details ---");
        String id = readNonEmptyString("Enter Patient ID to update: ");
        try {
            Patient existing = patientManager.searchPatient(id);
            System.out.println("Current details:");
            existing.displayDetails();

            String firstName = readNonEmptyString("Enter new First Name: ");
            String lastName = readNonEmptyString("Enter new Last Name: ");
            int age = readPositiveInt("Enter new Age: ");
            String gender = readNonEmptyString("Enter new Gender: ");
            String condition = readNonEmptyString("Enter new Medical Condition: ");

            patientManager.updatePatient(id, firstName, lastName, age, gender, condition);
            System.out.println("Patient updated successfully.");
        } catch (PatientNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }

    private void deletePatientFlow() {
        System.out.println("\n--- Delete Patient ---");
        String id = readNonEmptyString("Enter Patient ID to delete: ");
        try {
            Patient removed = patientManager.deletePatient(id);
            // If the patient held a bed, free it up too
            if (removed instanceof Inpatient inpatient && inpatient.getBedNumber() != null) {
                try {
                    ward.releaseBed(inpatient.getPatientId());
                } catch (BedUnavailableException ignored) {
                    // no bed to release, nothing to do
                }
            }
            System.out.println("Patient " + id + " deleted successfully.");
        } catch (PatientNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }

    // ---------------- Bed Management (Feature 2) ----------------

    private void allocateBedFlow() {
        System.out.println("\n--- Allocate Bed to Inpatient ---");
        String id = readNonEmptyString("Enter Patient ID: ");
        try {
            Patient patient = patientManager.searchPatient(id);
            if (!(patient instanceof Inpatient inpatient)) {
                System.out.println("Only Inpatients may be allocated a hospital bed.");
                return;
            }
            if (inpatient.getBedNumber() != null) {
                System.out.println("This patient already occupies bed " + inpatient.getBedNumber() + ".");
                return;
            }
            if (ward.isFull()) {
                System.out.println("Allocation failed: No beds are currently available.");
                return;
            }
            String bedId = ward.allocateFirstAvailableBed(inpatient);
            System.out.println("Bed " + bedId + " allocated to patient " + id + ".");
        } catch (PatientNotFoundException | BedUnavailableException e) {
            System.out.println(e.getMessage());
        }
    }

    private void releaseBedFlow() {
        System.out.println("\n--- Release Bed ---");
        String id = readNonEmptyString("Enter Patient ID: ");
        try {
            ward.releaseBed(id);
            // Reflect the release on the patient record too
            Patient patient = patientManager.searchPatient(id);
            if (patient instanceof Inpatient inpatient) {
                inpatient.setBedNumber(null);
            }
            System.out.println("Bed released for patient " + id + ".");
        } catch (BedUnavailableException | PatientNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }

    // ---------------- Reports (Feature 3) ----------------

    private void reportsMenu() {
        System.out.println("\n--- Reports Menu ---");
        System.out.println("1. All Registered Patients");
        System.out.println("2. Ward Occupancy Report");
        System.out.println("3. Patients Sorted by Surname");
        System.out.println("4. Patients Sorted by Patient ID");
        System.out.println("0. Back to Main Menu");
        int choice = readInt("Enter your choice: ");
        switch (choice) {
            case 1 -> patientManager.displayAllPatients();
            case 2 -> displayOccupancyReport();
            case 3 -> {
                patientManager.sortBySurname();
                patientManager.displayAllPatients();
            }
            case 4 -> {
                patientManager.sortByPatientId();
                patientManager.displayAllPatients();
            }
            case 0 -> System.out.println("Returning to main menu.");
            default -> System.out.println("Invalid choice.");
        }
    }

    private void displayOccupancyReport() {
        System.out.println("\n=== Ward Occupancy Report ===");
        System.out.println("Total Registered Patients : " + patientManager.getTotalRegistered());
        System.out.println("Total Beds                : " + Ward.TOTAL_BEDS);
        System.out.println("Occupied Beds              : " + ward.getOccupiedBedCount());
        System.out.println("Available Beds              : " + ward.getAvailableBedCount());
        System.out.printf("Ward Occupancy Percentage   : %.1f%%%n", ward.getOccupancyPercentage());
    }

    // ---------------- Input helper methods ----------------

    private String readNonEmptyString(String prompt) {
        String input;
        do {
            System.out.print(prompt);
            input = scanner.nextLine().trim();
            if (input.isEmpty()) {
                System.out.println("This field cannot be empty. Please try again.");
            }
        } while (input.isEmpty());
        return input;
    }

    private int readInt(String prompt) {
        while (true) {
            try {
                System.out.print(prompt);
                String line = scanner.nextLine().trim();
                return Integer.parseInt(line);
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a whole number.");
            }
        }
    }

    private int readPositiveInt(String prompt) {
        while (true) {
            int value = readInt(prompt);
            if (value > 0) {
                return value;
            }
            System.out.println("Please enter a positive number.");
        }
    }

    private PatientCategory readCategory() {
        while (true) {
            System.out.println("Select Patient Category:");
            System.out.println("1. Inpatient");
            System.out.println("2. Outpatient");
            System.out.println("3. Emergency");
            int choice = readInt("Enter choice: ");
            switch (choice) {
                case 1: return PatientCategory.INPATIENT;
                case 2: return PatientCategory.OUTPATIENT;
                case 3: return PatientCategory.EMERGENCY;
                default: System.out.println("Invalid category choice.");
            }
        }
    }
}
