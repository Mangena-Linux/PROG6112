package hospital;

/**
 * Represents an Inpatient, who requires a hospital bed.
 * Extends Patient and adds ward/bed information.
 */
public class Inpatient extends Patient {

    private int wardNumber;
    private String bedNumber; // e.g. "B01"

    public Inpatient(String patientId, String firstName, String lastName, int age,
                      String gender, String medicalCondition) {
        // Inpatient category is fixed - only inpatients get beds
        super(patientId, firstName, lastName, age, gender, medicalCondition, PatientCategory.INPATIENT);
        this.wardNumber = 1; // Assumption: hospital contains only one ward
        this.bedNumber = null; // not yet allocated a bed
    }

    public int getWardNumber() {
        return wardNumber;
    }

    public void setWardNumber(int wardNumber) {
        this.wardNumber = wardNumber;
    }

    public String getBedNumber() {
        return bedNumber;
    }

    public void setBedNumber(String bedNumber) {
        this.bedNumber = bedNumber;
    }

    /**
     * Overrides the superclass method to extend its behaviour and
     * include ward and bed information for the inpatient.
     */
    @Override
    public void displayDetails() {
        super.displayDetails();
        System.out.println("Ward Number      : " + wardNumber);
        System.out.println("Bed Number       : " + (bedNumber == null ? "Not allocated" : bedNumber));
    }

    @Override
    public String toString() {
        return super.toString() + " | Ward: " + wardNumber
                + " | Bed: " + (bedNumber == null ? "N/A" : bedNumber);
    }
}
