package hospital;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for the Hospital Patient Admission System (Feature 5).
 * Requires JUnit 5 (Jupiter) on the classpath.
 */
class HospitalSystemTest {

    private PatientManager patientManager;
    private Ward ward;

    @BeforeEach
    void setUp() {
        patientManager = new PatientManager();
        ward = new Ward();
    }

    // ---------------- CRUD Operation Tests ----------------

    @Test
    void testRegisterPatient() throws DuplicatePatientException {
        Patient p = new Patient("P001", "Thabo", "Nkosi", 34, "Male", "Flu", PatientCategory.OUTPATIENT);
        patientManager.registerPatient(p);
        assertEquals(1, patientManager.getTotalRegistered());
    }

    @Test
    void testSearchPatient() throws DuplicatePatientException, PatientNotFoundException {
        Patient p = new Patient("P002", "Lerato", "Dlamini", 29, "Female", "Migraine", PatientCategory.EMERGENCY);
        patientManager.registerPatient(p);
        Patient found = patientManager.searchPatient("P002");
        assertEquals("Dlamini", found.getLastName());
    }

    @Test
    void testUpdatePatientDetails() throws DuplicatePatientException, PatientNotFoundException {
        Patient p = new Patient("P003", "Sipho", "Zulu", 40, "Male", "Fracture", PatientCategory.OUTPATIENT);
        patientManager.registerPatient(p);
        patientManager.updatePatient("P003", "Sipho", "Zulu", 41, "Male", "Fracture - healing");
        Patient updated = patientManager.searchPatient("P003");
        assertEquals(41, updated.getAge());
        assertEquals("Fracture - healing", updated.getMedicalCondition());
    }

    @Test
    void testDeletePatient() throws DuplicatePatientException, PatientNotFoundException {
        Patient p = new Patient("P004", "Anele", "Khumalo", 22, "Female", "Asthma", PatientCategory.OUTPATIENT);
        patientManager.registerPatient(p);
        patientManager.deletePatient("P004");
        assertEquals(0, patientManager.getTotalRegistered());
        assertThrows(PatientNotFoundException.class, () -> patientManager.searchPatient("P004"));
    }

    // ---------------- Bed Management Tests ----------------

    @Test
    void testAllocateBed() throws BedUnavailableException {
        Inpatient inpatient = new Inpatient("P005", "Nomvula", "Mokoena", 55, "Female", "Pneumonia");
        String bedId = ward.allocateFirstAvailableBed(inpatient);
        assertEquals("B01", bedId);
        assertEquals("B01", inpatient.getBedNumber());
        assertEquals(19, ward.getAvailableBedCount());
    }

    @Test
    void testReleaseBed() throws BedUnavailableException {
        Inpatient inpatient = new Inpatient("P006", "Johan", "Botha", 61, "Male", "Cardiac observation");
        ward.allocateFirstAvailableBed(inpatient);
        ward.releaseBed("P006");
        assertEquals(20, ward.getAvailableBedCount());
        assertNull(inpatient.getBedNumber());
    }

    // ---------------- Validation and Boundary Tests ----------------

    @Test
    void testPreventDuplicatePatientIds() throws DuplicatePatientException {
        Patient p1 = new Patient("P007", "Kagiso", "Mahlangu", 30, "Male", "Sprain", PatientCategory.OUTPATIENT);
        Patient p2 = new Patient("P007", "Someone", "Else", 45, "Female", "Cold", PatientCategory.EMERGENCY);
        patientManager.registerPatient(p1);
        assertThrows(DuplicatePatientException.class, () -> patientManager.registerPatient(p2));
    }

    @Test
    void testPreventAllocatingOccupiedBed() throws BedUnavailableException {
        Inpatient p1 = new Inpatient("P008", "Ayanda", "Sithole", 38, "Female", "Surgery recovery");
        Inpatient p2 = new Inpatient("P009", "Bongani", "Ndlovu", 47, "Male", "Diabetes complications");
        ward.allocateBed("B01", p1);
        assertThrows(BedUnavailableException.class, () -> ward.allocateBed("B01", p2));
    }

    @Test
    void testPreventBedAllocationWhenWardFull() throws BedUnavailableException {
        // Fill all 20 beds
        for (int i = 1; i <= Ward.TOTAL_BEDS; i++) {
            Inpatient p = new Inpatient("F" + i, "First" + i, "Last" + i, 30, "Male", "Observation");
            ward.allocateFirstAvailableBed(p);
        }
        assertTrue(ward.isFull());
        Inpatient overflow = new Inpatient("P010", "Extra", "Patient", 50, "Male", "Overflow case");
        assertThrows(BedUnavailableException.class, () -> ward.allocateFirstAvailableBed(overflow));
    }

    @Test
    void testSortPatientsBySurname() throws DuplicatePatientException {
        patientManager.registerPatient(new Patient("P011", "Zola", "Zwane", 25, "Male", "Cold", PatientCategory.OUTPATIENT));
        patientManager.registerPatient(new Patient("P012", "Amy", "Adams", 33, "Female", "Cough", PatientCategory.OUTPATIENT));
        patientManager.registerPatient(new Patient("P013", "Mike", "Mokwena", 28, "Male", "Cold", PatientCategory.OUTPATIENT));

        patientManager.sortBySurname();
        List<Patient> patients = patientManager.getAllPatients();

        assertEquals("Adams", patients.get(0).getLastName());
        assertEquals("Mokwena", patients.get(1).getLastName());
        assertEquals("Zwane", patients.get(2).getLastName());
    }

    @Test
    void testPreventDoubleBookingSamePatient() throws BedUnavailableException {
        // A patient must not be allocated a second bed while already holding one
        Inpatient patient = new Inpatient("P015", "Double", "Booking", 36, "Male", "Check");
        ward.allocateFirstAvailableBed(patient);
        assertThrows(BedUnavailableException.class, () -> ward.allocateFirstAvailableBed(patient));
        assertEquals(19, ward.getAvailableBedCount(), "Available count must not drop again on the blocked second allocation");
    }

    @Test
    void testBedIdIsStoredInCanonicalForm() throws BedUnavailableException {
        // Regardless of the case used when allocating, the stored bed number
        // must match what the ward layout displays (e.g. "B07", not "b07")
        Inpatient patient = new Inpatient("P016", "Case", "Sensitivity", 27, "Female", "Check");
        ward.allocateBed("b07", patient);
        assertEquals("B07", patient.getBedNumber());
    }

    @Test
    void testInheritanceAndOverriddenDisplay() {
        Inpatient inpatient = new Inpatient("P014", "Palesa", "Moeketsi", 44, "Female", "Post-op");
        // Inheritance: an Inpatient IS-A Patient
        assertTrue(inpatient instanceof Patient);
        assertEquals(PatientCategory.INPATIENT, inpatient.getCategory());
    }
}
